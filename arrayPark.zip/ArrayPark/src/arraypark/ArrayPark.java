/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraypark;

/**
 *
 * @author martin
 */
public class ArrayPark {

    public static void main(String[] args) {
        int[] numbers = {4, -7, 9, 3, -1, 6, -2, 5, 8};
        int[] values = {-9, 0, -2, 4, 5, -7, -3, 6, 1, -8};

        System.out.println("--- numbers ---");
        testSuit(numbers);

        System.out.println("--- values ---");
        testSuit(values);

    }

    static void testSuit(int[] nums) {
        printIntArray(nums);
        int result = maxElement(nums);
        System.out.println("max: " + result);
        double meanVal = mean(nums);
        System.out.printf("meanVal: %5.2f \n", meanVal);

        separateOddEven(nums);
        printIntArray(nums);

        removeNegative(nums);
        printIntArray(nums);
        return;
    }

    static int maxElement(int[] nums) {
   
        return 
    }

    static double mean(int[] nums) {
    
        return 
    }

    static void separateOddEven(int[] nums) {
       
        return;
    }

    static void removeNegative(int[] nums) {
      
        return;
    }

    static void printIntArray(int[] nums) {
        System.out.print("Array: ");
        for (int i = 0; i < nums.length; i = i + 1) {
            System.out.print(nums[i] + ", ");
        }
        System.out.println();
        return;
    }

}
