package array;
//import java.util.Scanner;
public class Array {
    
    public static void main(String[] args) {
        //Scanner ts= new Scanner (System.in);
        int[] numbers = {4, -7, 9, 3, -1, 6, -2, 5, 8};
        int[] values = {-9, 0, -2, 4, 5, -7, -3, 6, 1, -8};
        System.out.println("--- numbers ---");
        testSuit(numbers);
        
        System.out.println("--- values ---");
        testSuit(values);
        
    } 
    static void testSuit(int[] nums) {
        printIntArray(nums);
        int result = maxElement (nums);
        System.out.println("max: " + result);
        double m = mittelwert(nums);
        System.out.printf("Mittelwert: %5.2f \n", m); 
        //changeNegative(nums);
        
        java.util.Arrays.sort(nums);    //Sortiert die Arrays nach größe
        System.out.print("Sortet ");
        printIntArray(nums);
        // seperateOddEvent(nums);
        removeNegative(nums);
        printIntArray(nums);
        }
    
    static int maxElement (int[] nums) {

        int max = nums[nums.length - 1];
        return max;
    }
    
    static double mittelwert(int[] nums) {
        
        int l = nums.length;
        
        double sum = 0;
        for (int i = 0; i < l; i++) {
            sum += nums[i];
        }
        double m = sum / l;
        return m;
    }
    
    static void changeNegative(int[] nums) {
        System.out.print("Array all Positive: ");
        for (int i = 0; i < nums.length; i = i +1) {
           if (nums[i] < 0){
               nums[i]= nums[i] * -1;
               System.out.print("+");
           }
           System.out.print( nums[i] + ", ");
        }
        System.out.println("");
        
    }
    static void seperateOddEvent(int[] nums) {
    /**for (int i = 0; i < nums.length; i = i +1) {
           if ( nums[i] %2 != 0) {
               nums[i]= 0;
           }
        }*/
    
    }
    
    static void removeNegative(int[] nums) {
        System.out.print("Array ohne Negative: ");
            
            for (int i = 0; i < nums.length; i = i + 1) {
                if( nums[i] < 0) {
                    
                    
                }
            System.out.print(nums[i] + ", ");
        }
        System.out.println();
        
        int[] falschrum = new int[nums.length];
        
        for (int i = 0; i < falschrum.length; i++) {
            
            for (int j = nums.length-1; j > 0; j--) {
                falschrum[i] = nums [j];
                
            }
        }
        for (int i = 0; 10 < nums.length; i = i + 1) {
            
            nums[i] = falschrum[i];
            System.out.print(nums[i] + ", ");
            
        }
    }
    
    static void printIntArray(int[] nums) { //Listet das Arrray in sdeinem derzeitigen zustand auf
        System.out.print("Array: ");
        for (int i = 0; i < nums.length; i = i + 1) {
            System.out.print(nums[i] + ", ");
        }
        System.out.println();
    }
}
