/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unicode;

/**
 *
 * @author johan
 */
public class Unicode {
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        for(int s= 32; s<=87; s= s+1){
            for(int z=0; s+z<=255; z= z+56){
            System.out.print(s+z+" "+(char) (s+z)+"\t");
            }
        System.out.println("");
        }
    }
}