/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplikationstabelle.pkg2.pkg0;

/**
 *
 * @author johan
 */
import java.util.Scanner;
public class Multiplikationstabelle20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ts=new Scanner(System.in);
        System.out.print("Spalten: ");
        int Spalten = ts.nextInt();
        System.out.print("Zeilen: ");
        int Zeilen = ts.nextInt();
        
        int s=1;
        int z=1;
        while(s <= Spalten){
            while(z <= Zeilen){
                System.out.print(s*z + "\t");
                z= z+1;
                }
        System.out.println("");
        s= s+1;
        z=1;
        }
    }
    
}
